package com.example.administrator.gte.Home_Activity.City_List;

/**
 * Created by Administrator on 2015/9/7.
 */
public class City {
    private String name;

    public City(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }
}
